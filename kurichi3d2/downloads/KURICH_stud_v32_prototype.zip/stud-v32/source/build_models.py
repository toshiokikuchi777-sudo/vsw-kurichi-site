from pathlib import Path
import json, zipfile, csv
from xml.sax.saxutils import escape
import numpy as np
import manifold3d as M
import trimesh
ROOT=Path(__file__).resolve().parent.parent
W=235.;H=458/3;B=6.;EPS=.01
records=[]
def box(x,y,z,w,h,d):return M.Manifold.cube((w,h,d)).translate((x,y,z))
def union(items):return M.Manifold.batch_boolean(items,M.OpType.Add)
def minus(a,items):return M.Manifold.batch_boolean([a]+items,M.OpType.Subtract)
def intersect(a,b):return M.Manifold.batch_boolean([a,b],M.OpType.Intersect)
def mesh(s):
 m=s.to_mesh();return trimesh.Trimesh(vertices=np.array(m.vert_properties)[:,:3],faces=np.array(m.tri_verts),process=True)
def write3mf(m,path):
 vertices=''.join(f'<vertex x="{v[0]:.8f}" y="{v[1]:.8f}" z="{v[2]:.8f}"/>' for v in m.vertices)
 tris=''.join(f'<triangle v1="{f[0]}" v2="{f[1]}" v3="{f[2]}"/>' for f in m.faces)
 model=f'<?xml version="1.0" encoding="UTF-8"?><model unit="millimeter" xml:lang="en-US" xmlns="http://schemas.microsoft.com/3dmanufacturing/core/2015/02"><metadata name="Title">{escape(path.stem)}</metadata><resources><object id="1" type="model"><mesh><vertices>{vertices}</vertices><triangles>{tris}</triangles></mesh></object></resources><build><item objectid="1"/></build></model>'
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
  z.writestr('[Content_Types].xml','<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/></Types>')
  z.writestr('_rels/.rels','<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Target="/3D/3dmodel.model" Id="rel0" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/></Relationships>')
  z.writestr('3D/3dmodel.model',model)
def save(s,rel,qty=1,three=False):
 path=ROOT/rel;m=mesh(s)
 assert s.status()==M.Error.NoError,(rel,s.status())
 assert m.is_watertight and m.is_winding_consistent and m.volume>0,rel
 assert len(s.decompose())==1,(rel,'disconnected')
 m.export(path)
 if three:write3mf(m,path.with_suffix('.3mf'))
 records.append(dict(file=rel,quantity=qty,vertices=len(m.vertices),triangles=len(m.faces),watertight=bool(m.is_watertight),components=len(s.decompose()),bounds_mm=m.bounds.tolist(),size_mm=m.extents.tolist(),volume_mm3=float(m.volume)))
 return m

# Nominal System-style geometry, not a certified reproduction of a molded part.
def cyl(x,y,z,d,h):return M.Manifold.cylinder(h,d/2,d/2,64).translate((x,y,z))
def studs(cx,cy,z,vertical=False,d=4.8):
 return [cyl(cx+(0 if vertical else t),cy+(t if vertical else 0),z,d,1.0) for t in [-12,-4,4,12]]
def socket_cuts(cx,cy,z,vertical=False,c=0):
 # Open underside with side walls and three intermediate solid posts (1-wide strip).
 w,h=(4.8+2*c,28.8+2*c) if vertical else (28.8+2*c,4.8+2*c)
 hollow=box(cx-w/2,cy-h/2,z-EPS,w,h,1.2+EPS)
 posts=[cyl(cx+(0 if vertical else t),cy+(t if vertical else 0),z-EPS,3.2-2*c,1.2+2*EPS) for t in [-8,0,8]]
 return minus(hollow,posts)
def module(top=True,c=0):
 a=minus(box(0,0,0,31.8,7.8,2.0),[socket_cuts(15.9,3.9,0,c=c)])
 return union([a]+studs(15.9,3.9,2.0)) if top else a
def label(kind,c=0):
 w,h=(75,23) if kind=='product' else (100,28)
 a=box(0,0,0,w,h,3)
 centers=[(8,11.5),(67,11.5)] if kind=='product' else [(8,24),(92,24)]
 return minus(a,[cyl(x,y,-EPS,5,2.2+EPS) for x,y in centers])
OUTLINES=json.loads((ROOT/'source/text_outlines.json').read_text())
def category_text(word):
 outline=M.CrossSection(OUTLINES[word],M.FillRule.EvenOdd)
 cutter=outline.extrude(.3+EPS).translate((0,0,2.7))
 a=minus(label('category'),[cutter])
 assert abs(intersect(a,box(0,0,2.2,100,28,.5)).volume()-1400)<1e-4,'minimum skin 0.5mm'
 assert abs((label('category')-a).volume()-outline.area()*.3)<1e-3
 if word in ['CLASIC','FUWA_MOCHI','WOOPEE']:a=union([a]+[cyl(x,4.4,3-EPS,4.8,1.6+EPS) for x in [22,30,38,46,54,62,70,78]])
 return a

PRODUCTS=json.loads((ROOT/'source/product_names.json').read_text())
def product_text(slug):
 if slug=='blank':return label('product')
 outline=M.CrossSection(OUTLINES[slug],M.FillRule.EvenOdd).simplify(.005)
 a=minus(label('product'),[outline.extrude(.3+EPS).translate((0,0,2.7))])
 assert abs(intersect(a,box(0,0,2.2,75,23,.5)).volume()-862.5)<1e-4
 assert abs((label('product')-a).volume()-outline.area()*.3)<1e-3
 return a
def pocket(cx,cy,v):
 w,h=(8.2,32.2) if v else (32.2,8.2)
 return box(cx-w/2,cy-h/2,4,w,h,2+EPS)
def label_recess(kind,x,y):
 w,h=(75,23) if kind=='product' else (100,28)
 cuts=[box(x-.2,y-.2,3,w+.4,h+.4,3+EPS)]
 return cuts

def external_stud_centers(col):
 lw=15 if col==0 else 7.5;outer=7.5 if col==0 else W-7.5
 side=[(outer,float(y)) for y in np.arange(24,H-20,8)]
 origin=lw+50-28
 horizontal=[(origin+8*i,H-2.5) for i in range(-40,40) if 2.4<=origin+8*i<=W-2.4 and abs(origin+8*i-outer)>8.5]
 return side+horizontal

def price_tile(slug):
 a=minus(box(0,0,0,15.8,7.8,3.2),[cyl(x,3.9,-EPS,5,1.8+EPS) for x in [3.9,11.9]])
 outline=M.CrossSection(OUTLINES['price_'+slug],M.FillRule.EvenOdd).simplify(.005)
 return minus(a,[outline.extrude(.3+EPS).translate((0,0,2.9))])

def unit(row,col):
 lw=15 if col==0 else 7.5;rw=7.5 if col==0 else 15
 f=union([box(0,0,0,W,30,B),box(0,H-15,0,W,15,B),box(0,30,0,lw,H-45,B),box(W-rw,30,0,rw,H-45,B)])
 mounts=[];slots=[]
 for px in ([30,137.5] if col==0 else [22.5,130]):
  slots.append(('product',px,7.0))
  mounts += [cyl(px+dx,18.5,3-EPS,4.8,2.0+EPS) for dx in [8,67]]
 category_x=lw
 slots.append(('category',category_x,H-33))
 mounts += [cyl(category_x+dx,H-9,3-EPS,4.8,2.0+EPS) for dx in [8,92]]
 connectors=[];outer=7.5 if col==0 else W-7.5;center=W if col==0 else 0
 connectors.append((outer,H,True))
 connectors.append((outer,0,True))
 connectors.append((center,15,False))
 f=minus(f,[pocket(*a) for a in connectors]+[cut for kind,x,y in slots for cut in label_recess(kind,x,y)])
 for cx,cy,v in connectors:
  # Front-facing studs rise from the recessed floor z=1.8.
  for t in [-12,-4,4,12]:
   x=cx+(0 if v else t);y=cy+(t if v else 0)
   if x>0 and x<W and y>0 and y<H:mounts.append(cyl(x,y,4-EPS,4.8,1.0+EPS))
 mounts += [cyl(x,y,6-EPS,4.8,1.6+EPS) for x,y in external_stud_centers(col)]
 return union([f]+mounts),slots

frames=[];labels=[]
for r in range(3):
 for c in range(2):
  n=r*2+c+1;f,slots=unit(r,c);off=(c*W,(2-r)*H,0)
  if r==0:save(f,f'units/common_{"left" if c==0 else "right"}.stl',qty=3,three=True)
  frames.append(f.translate(off))
  for j,(kind,x,y) in enumerate(slots):
   a=category_text(['CLASIC','FUWA_MOCHI','WOOPEE'][r]) if kind=='category' else product_text(PRODUCTS[r*4+c*2+j][0] if r<2 else 'blank')
   labels.append(a.translate((off[0]+x,off[1]+y,3)))
for slug,en,ja in PRODUCTS:save(product_text(slug),f'plates/product_{slug}.stl',qty=1,three=True)
save(label('product'),'plates/product_blank.stl',qty=4,three=True)
for word in ['CLASIC','FUWA_MOCHI','WOOPEE']:save(category_text(word),f'plates/category_{word.lower()}.stl',qty=2,three=True)
save(module(),'joints/connector_1x4_nominal.stl',qty=7,three=True)
for d in [4.8,4.85,4.9]:
 a=union([box(0,0,0,31.8,7.8,2.0)]+studs(15.9,3.9,2.0,d=d))
 save(a,f'tests/male_d{d:.2f}.stl')
for c in [0,.05,.1]:save(module(c=c),f'tests/female_clearance_{c:.2f}.stl')
# Small two-piece seam coupon: front recesses are the same as the full frame.
for side in [0,1]:
 y=side*20
 a=minus(box(0,y,0,15,20,B),[pocket(7.5,20,True)])
 a=union([a]+[cyl(7.5,t,4-EPS,4.8,1.0+EPS) for t in ([8,16] if side==0 else [24,32])])
 save(a.translate((0,-y,0)),f'tests/seam_half_{side+1}.stl')
# Flush label coupon: same 75x23 label and recessed attachment as full frame.
a=minus(box(0,0,0,85,30,B),label_recess('product',5,7))
a=union([a]+[cyl(5+dx,18.5,3-EPS,4.8,2.0+EPS) for dx in [8,67]])
save(a,'tests/flush_product_frame.stl')
save(label('product'),'tests/flush_product_plate.stl')
# Geometric checks do not establish frictional retention or real LEGO compatibility.
for i,a in enumerate(frames):
 for b in frames[i+1:]:assert abs(intersect(a,b).volume())<1e-5
full=union(frames)
for i,a in enumerate(labels):
 assert abs(intersect(a,full).volume())<1e-5
 for b in labels[i+1:]:assert abs(intersect(a,b).volume())<1e-5
 # Pulling straight forward releases each nameplate without neighbor collision.
 for dz in [.5,1,2,5,10]:
  moved=a.translate((0,0,dz))
  assert abs(intersect(moved,full).volume())<1e-5
  for j,b in enumerate(labels):
   if i!=j:assert abs(intersect(moved,b).volume())<1e-5
keys=[]
# Underside opens toward the front-facing studs; connector sits at z=1.8.
k=module().translate((-15.9,-3.9,4))
for y in [H,2*H]:
 for x in [7.5,462.5]:keys.append(k.rotate((0,0,90)).translate((x,y,0)))
for y in [15,H+15,2*H+15]:keys.append(k.translate((235,y,0)))
def sweep_forward(a,travel=20):
 sweeps=[]
 for tri in mesh(a).triangles:
  hull=M.Manifold.hull_points(np.vstack([tri,tri+[0,0,travel]]))
  if hull.volume()>1e-10:sweeps.append(hull)
 return union([a]+sweeps)
for i,a in enumerate(keys):
 assert abs(intersect(a,full).volume())<1e-5
 swept=sweep_forward(a)
 assert abs(intersect(swept,full).volume())<1e-4,'connector continuous frame path'
 for b in labels:assert abs(intersect(swept,b).volume())<1e-4,'connector continuous label path'
 for j,b in enumerate(keys):
  if i!=j:assert abs(intersect(swept,b).volume())<1e-4,'connector continuous connector path'
for i,a in enumerate(labels):
 assert abs(mesh(a).bounds[1,2]-(7.6 if i%3==2 else 6))<1e-5,'label face not flush'
 swept=sweep_forward(a)
 assert abs(intersect(swept,full).volume())<1e-4,'label continuous frame path'
 for j,b in enumerate(labels):
  if i!=j:assert abs(intersect(swept,b).volume())<1e-4,'label continuous label path'
 for b in keys:assert abs(intersect(swept,b).volume())<1e-4,'label continuous connector path'
for kind in ['product','category']:
 m=mesh(label(kind));w,h=(75,23) if kind=='product' else (100,28)
 assert np.allclose(m.bounds,[[0,0,0],[w,h,3]])
 assert abs(intersect(label(kind),box(0,0,2.2,w,h,.8)).volume()-w*h*.8)<1e-4
 expected=w*h*3-2*mesh(cyl(0,0,0,5,2.2)).volume
 assert abs(m.volume-expected)<1e-3
 centers=[(8,11.5),(67,11.5)] if kind=='product' else [(8,24),(92,24)]
 for x,y in centers:
  assert abs(intersect(label(kind),cyl(x,y,-EPS,4.8,2.01)).volume())<1e-6
  skin=box(x-2,y-2,2.2,4,4,.8)
  assert abs(intersect(label(kind),skin).volume()-12.8)<1e-5,'front skin must be solid'
# Product recesses reach past y=30 at their top, removing the thin upper rim.
for c in [0,1]:
 f,slots=unit(0,c)
 for kind,x,y in slots:
  centers=[(8,11.5),(67,11.5)] if kind=='product' else [(8,24),(92,24)]
  for dx,dy in centers:
   floor=box(x+dx-1,y+dy-1,0,2,2,3)
   assert abs(intersect(f,floor).volume()-12)<1e-5,'3mm solid floor under label pins'
  if kind=='product':
   assert y==7 and y+23==30
   probe=box(x,29.9,3.01,75,.2,2.98)
   assert abs(intersect(f,probe).volume())<1e-6,'product recess top must be open'
for c in [0,1]:
 f,_=unit(0,c);outer=7.5 if c==0 else W-7.5
 for yy in [4,H-4]:
  floor=box(outer-1,yy-1,0,2,2,4)
  assert abs(intersect(f,floor).volume()-16)<1e-5,'joint floor must be solid 4mm'
assert np.allclose(mesh(module()).extents,[31.8,7.8,3])
assert 4+2==B,'connector body must finish flush with frame'
prices=[];layout=[]
for row in range(3):
 for col in range(2):
  center=(15 if col==0 else 7.5)+50
  for i,slug in enumerate(['yen','five','zero','zero']):
   xyz=[col*W+center-31.9+16*i,((2-row)*H+H-33+.5),6]
   a=price_tile(slug).translate(xyz);prices.append(a)
   layout.append(dict(unit_index=row*2+col,char={'yen':'yen','five':'5','zero':'0'}[slug],file=f'price_{slug}.stl',position=xyz,x=xyz[0],y=xyz[1],z=xyz[2]))
for slug,qty in [('yen',6),('five',6),('zero',12),('six',6)]:save(price_tile(slug),f'plates/price_{slug}.stl',qty=qty,three=True)
save(union([box(0,0,0,15.8,7.8,6)]+[cyl(x,3.9,6-EPS,4.8,1.6+EPS) for x in [3.9,11.9]]),'tests/price_stud_coupon.stl')
save(price_tile('five'),'tests/price_tile_five.stl')
for i,a in enumerate(prices):
 for b in frames+labels+keys+prices[i+1:]:assert abs(intersect(a,b).volume())<1e-4,'price installed collision'
 swept=sweep_forward(a)
 for b in frames+labels+keys:assert abs(intersect(swept,b).volume())<1e-4,'price forward collision'
# Swap five for six at all six positions; same body, independently verify its fit.
for item in layout:
 if item['char']=='5':
  a=price_tile('six').translate(item['position'])
  for b in frames+labels+keys:assert abs(intersect(a,b).volume())<1e-4
def retaining_bar():
 return minus(box(0,0,0,95.8,7.8,3.2),[cyl(3.9+8*i,3.9,-EPS,5,1.6+EPS) for i in range(12)])
save(retaining_bar(),'joints/category_retainer.stl',qty=6,three=True)
bars=[];bar_layout=[]
for row in range(3):
 for col in range(2):
  lw=15 if col==0 else 7.5
  xyz=[col*W+lw+2.1,(2-row)*H+H-6.4,6.3]
  a=retaining_bar().translate(xyz);bars.append(a)
  bar_layout.append(dict(unit_index=row*2+col,file='category_retainer.stl',position=xyz,rotation=[0,0,0]))
  for b in frames+labels+keys+prices:assert abs(intersect(a,b).volume())<1e-4,'bar installed collision'
  swept=sweep_forward(a)
  for b in frames+labels+keys+prices:assert abs(intersect(swept,b).volume())<1e-4,'bar removal collision'
  cat=labels[(row*2+col)*3+2]
  assert intersect(cat.translate((0,0,.5)),a).volume()>.01,'bar must block category'
for i,a in enumerate(bars):
 for b in bars[i+1:]:assert abs(intersect(a,b).volume())<1e-5
(ROOT/'bar_layout.json').write_text(json.dumps(dict(file='category_retainer.stl',quantity=6,size=[95.8,7.8,3.2],color='#D9232E',items=bar_layout,hole_count=12,hole_pitch=8,hole_diameter=5,hole_depth=1.6,overlap_category=1.4,front_gap=.3,assembly_bounds=[[0,0,0],[470,459.4,9.5]],removal='pull bar forward, then remove category'),indent=2))
assembly=union(frames+labels+keys+prices+bars)
(ROOT/'price_layout.json').write_text(json.dumps(dict(tileSize=[15.8,7.8,3.2],files={a:f'price_{a}.stl' for a in ['yen','five','six','zero']},items=layout,assembled_bounds=[[0,0,0],[470,458,9.2]],external_stud_height=1.6,external_stud_diameter=4.8,external_stud_pitch=8,unit_stud_centers={str(c):external_stud_centers(c) for c in [0,1]}),indent=2))
assert np.allclose(mesh(assembly).bounds,[[0,0,0],[470,459.4,9.5]],atol=1e-4)
P=dict(bar_layout="bar_layout.json",bar_quantity=6,price_layout="price_layout.json",external_stud_height=1.6,external_stud_pitch=8,external_stud_diameter=4.8,base_depth=6,price_tile_size=[15.8,7.8,3.2],product_names=PRODUCTS,product_layout="first eight left-to-right across top and middle; bottom four blank; provisional",product_engraving_depth=.3,category_text_rows=["CLASIC","FUWA_MOCHI","WOOPEE"],category_engraving_depth=.3,category_min_skin=.5,frame_types=2,frame_quantities={"common_left":3,"common_right":3},unused_endpoint_recesses="outer top and bottom half-key seats visible; no keys installed",assembly=[470,458],unit=[235,H],frame_thickness=6,stud_pitch=8,stud_diameter_nominal=4.8,stud_height=1.0,module_body=[31.8,7.8,2.0],module_with_studs_height=3,module_socket_depth=1.2,module_socket_inner_width_nominal=4.8,module_post_diameter_nominal=3.2,front_recess_depth=2,front_recess_floor_z=4,connector_seated_z=[4,7],unit02_category_x=7.5,label_thickness_total=3,assembled_depth=9.5,label_seated_z=[3,6],label_face_z=[3,6],label_recess_depth=3,label_mount="all labels: two underside blind holes",product_hole_diameter=5.0,product_pin_diameter=4.8,product_pin_height=2.0,product_hole_centers=[[8,11.5],[67,11.5]],product_pin_seated_z=[3,5],label_blind_hole_depth=2.2,label_front_skin=.8,category_hole_centers=[[8,24],[92,24]],category_pin_height=2.0,label_retention="clearance fit prototype; locking unverified",label_recess_xy_clearance=.2,product_finger_recess=None,product_local_y=7,product_recess_top_open=True,category=[100,28],product=[75,23],compatibility='custom thin connector; NOT LEGO standard height compatible; physical fit unverified')
(ROOT/'parameters.json').write_text(json.dumps(P,indent=2))
(ROOT/'validation.json').write_text(json.dumps(dict(parts=records,unit_overlap='zero positive volume',seated_labels_checked=18,forward_travel_samples_per_label=5,label_continuous_forward_travel_mm=20,label_connector_pairs_checked=126,assembly_parts=61,assembly_bounds_mm=mesh(assembly).bounds.tolist(),all_label_front_faces_z_mm=6,label_shape='all labels: 3mm plate, two diameter5 depth2.2 blind holes, unengraved frontskin0.8; engraved minimum0.5',label_receivers='all labels two diameter4.8 height2.0 pins',label_retention='clearance fit, locking unverified',minimum_skin_mm=.5,unengraved_skin_mm=.8,blind_hole_depth_mm=2.2,category_pin_connected=True,label_pin_floor_thickness_checked_mm=3,joint_floor_thickness_checked_mm=4,product_recess_top_open_checked=True,installed_connectors_checked=7,connector_label_pairs_checked=126,connector_continuous_forward_travel_mm=20,connector_travel_samples_per_part=7,price_tiles_checked=24,swappable_six_tiles_checked=6,external_stud_geometry_source='https://www.ldraw.org/article/218.html',bar_installed_count=6,bar_block_category_forward=True,bar_removal_continuous=True,physical_fit='not tested; bar stud friction retention unverified'),indent=2))
print('Validated',len(records),'watertight single-component STL parts; 6 frames, 18 labels, 7 connectors.')

with (ROOT/'parts_list.csv').open('w',newline='') as out:
 writer=csv.writer(out);writer.writerow(['file','quantity','size_mm'])
 writer.writerows((r['file'],r['quantity'],' x '.join(str(round(a,4)) for a in r['size_mm'])) for r in records if not r['file'].startswith('tests/'))
