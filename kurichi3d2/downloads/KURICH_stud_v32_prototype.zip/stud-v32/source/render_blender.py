import bpy,struct
from pathlib import Path
from mathutils import Vector
ROOT=Path(__file__).resolve().parent.parent
H=458/3
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
scene=bpy.context.scene
scene.render.engine='BLENDER_WORKBENCH'
scene.render.resolution_x=1400;scene.render.resolution_y=1050;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG'
shade=scene.display.shading;shade.light='STUDIO';shade.color_type='MATERIAL';shade.show_shadows=True;shade.show_cavity=True;shade.cavity_type='BOTH';shade.curvature_ridge_factor=1.4;shade.curvature_valley_factor=1.1;shade.show_object_outline=True;shade.background_type='WORLD';scene.world.color=(.82,.85,.88)
scene.view_settings.view_transform='Standard'
mat=[]
for name,c in [('Frame',(.85,.137,.18,1)),('Plate',(.96,.96,.96,1)),('Joint',(.85,.137,.18,1)),('Ink',(.015,.015,.015,1))]:
 m=bpy.data.materials.new(name);m.diffuse_color=c;mat.append(m)
def obj(path,loc=(0,0,0),mi=0):
 data=Path(path).read_bytes();n=struct.unpack_from('<I',data,80)[0];verts=[];faces=[]
 for i in range(n):
  a=struct.unpack_from('<12fH',data,84+50*i);k=len(verts);verts.extend([a[3:6],a[6:9],a[9:12]]);faces.append((k,k+1,k+2))
 mesh=bpy.data.meshes.new(Path(path).stem);mesh.from_pydata(verts,[],faces);mesh.update();o=bpy.data.objects.new(mesh.name,mesh);scene.collection.objects.link(o);o.location=loc;o.data.materials.append(mat[mi])
 if mi==1:
  o.data.materials.append(mat[3]);floor=2.9 if Path(path).stem.startswith('price_') else 2.7
  for face in mesh.polygons:
   if all(abs(mesh.vertices[v].co.z-floor)<.0001 for v in face.vertices) and face.normal.z>.5:face.material_index=1
 return o
def clear():
 for o in list(scene.objects):bpy.data.objects.remove(o,do_unlink=True)
def render(name,eye,target,scale):
 camdata=bpy.data.cameras.new('Camera');cam=bpy.data.objects.new('Camera',camdata);scene.collection.objects.link(cam);cam.location=eye;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler();camdata.type='ORTHO';camdata.ortho_scale=scale;camdata.clip_end=10000;scene.camera=cam;scene.render.filepath=str(ROOT/'previews'/name);bpy.ops.render.render(write_still=True)
obj(ROOT/'units/common_left.stl')
obj(ROOT/'plates/product_cranberry_nuts.stl',(30,7,38),1)
obj(ROOT/'plates/product_cranberry_nuts.stl',(137.5,7,3),1)
obj(ROOT/'plates/category_clasic.stl',(15,H-33,3),1)
for i,slug in enumerate(['yen','five','zero','zero']):obj(ROOT/f'plates/price_{slug}.stl',(65-31.9+16*i,H-32.5,6),1)
obj(ROOT/'joints/category_retainer.stl',(17.1,H-6.4,6.3),2)
render('03_label_exploded.png',(360,-300,480),(117.5,H/2,10),295)
clear()
obj(ROOT/'tests/seam_half_1.stl')
obj(ROOT/'tests/seam_half_2.stl',(0,20,0))
a=obj(ROOT/'joints/connector_1x4_nominal.stl',(11.4,4.1,20),2)
a.rotation_euler=(0,0,1.5707963267948966)
render('04_front_connector_exploded.png',(55,-55,100),(7.5,20,8),70)

clear()
obj(ROOT/'tests/flush_product_frame.stl')
obj(ROOT/'plates/product_cranberry_nuts.stl',(5,7,3),1)
render('06_flush_coupon_3d.png',(110,-80,48),(42.5,16.5,4),100)
