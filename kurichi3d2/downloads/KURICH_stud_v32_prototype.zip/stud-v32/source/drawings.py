from pathlib import Path
import html,json
LAYOUT=json.loads((Path(__file__).parent.parent/'price_layout.json').read_text())
PRODUCTS=json.loads((Path(__file__).parent/'product_names.json').read_text())
D=Path(__file__).resolve().parent.parent/'drawings'
dark='#161616';blue='#237697';red='#d9232e';light='#ffffff';muted='#647885'
BARS=json.loads((Path(__file__).parent.parent/'bar_layout.json').read_text())
OUTLINES=json.loads((Path(__file__).parent/'text_outlines.json').read_text())
s=[]
def rect(x,y,w,h,fill,stroke='none',sw=.35):s.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')
def line(x,y,x2,y2,color=blue,dash=False,sw=.4):s.append(f'<path d="M{x},{y}L{x2},{y2}" fill="none" stroke="{color}" stroke-width="{sw}"'+(' stroke-dasharray="2 2"' if dash else '')+'/>')
def circle(x,y,r,fill='white',stroke=blue,dash=False):s.append(f'<circle cx="{x}" cy="{y}" r="{r}" fill="{fill}" stroke="{stroke}" stroke-width=".35"'+(' stroke-dasharray="1 1"' if dash else '')+'/>')
def text(t,x,y,size=5,color=dark,anchor='start'):s.append(f'<text x="{x}" y="{y}" font-size="{size}" fill="{color}" text-anchor="{anchor}" font-family="Hiragino Sans,Arial,sans-serif">{html.escape(t)}</text>')
def lettering(key,x,y,height,scale=1):
 contours=OUTLINES[key]
 path=' '.join('M'+' L'.join(f'{x+px*scale:.5f},{y+(height-py)*scale:.5f}' for px,py in q)+' Z' for q in contours)
 s.append(f'<path d="{path}" fill="{dark}" fill-rule="evenodd"/>')
def hd(x,x2,y,ref,t):
 for a in [x,x2]:line(a,ref,a,y-2);line(a-1.5,y+1.5,a+1.5,y-1.5)
 line(x,y,x2,y);text(t,(x+x2)/2,y-3,5,blue,'middle')
def vd(y,y2,x,ref,t):
 for a in [y,y2]:line(ref,a,x+2,a);line(x-1.5,a+1.5,x+1.5,a-1.5)
 line(x,y,x,y2);s.append(f'<text transform="translate({x-3},{(y+y2)/2}) rotate(-90)" text-anchor="middle" font-size="5" fill="{blue}" font-family="Arial">{t}</text>')
def save(name,w,h):
 (D/name).write_text(f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}mm" height="{h}mm" viewBox="0 0 {w} {h}"><rect width="100%" height="100%" fill="white"/>'+''.join(s)+'</svg>')
def notes(lines,x,y,step=11,size=5):
 for i,t in enumerate(lines):text(t,x,y+i*step,size)

text('KURICH｜全札を裏側2穴で位置決めする枠',55,25,10)
text('V32  /  正面寸法図 1:1  /  単位 mm  /  ベース6mm＋外付け価格／全カテゴリ文字下に価格／押さえバー付き厚9.5mm',55,39,5,muted)
ox,oy=55,88;H=458/3
for r in range(3):
 for c in range(2):
  x,y=ox+c*235,oy+r*H;n=r*2+c+1;lw=15 if c==0 else 7.5;rw=7.5 if c==0 else 15
  for a,b,w,h in [(x,y,235,15),(x,y+H-30,235,30),(x,y+15,lw,H-45),(x+235-rw,y+15,rw,H-45)]:rect(a,b,w,h,red)
  category_x=lw
  rect(x+category_x,y+5,100,28,light,dark)
  for dx in [8,92]:circle(x+category_x+dx,y+9,2.5,'none',blue,True)
  lettering(['CLASIC','FUWA_MOCHI','WOOPEE'][r],x+category_x,y+5,28)
  for j,px in enumerate([30,137.5] if c==0 else [22.5,130]):
   py=y+H-30;rect(x+px,py,75,23,light,dark)
   for dx in [8,67]:circle(x+px+dx,py+11.5,2.5,'none',blue,True)
   if r<2:
    slug,en,ja=PRODUCTS[r*4+c*2+j]
    lettering(slug,x+px,py,23)
  text(f'UNIT {n:02d} / '+('共通L' if c==0 else '共通R'),x+117.5,y+75,8,muted,'middle')
  text('235 × 152.667',x+117.5,y+88,5,muted,'middle')
# Unused outer half-key seats remain at the four assembly endpoints.
for xx in [ox+7.5,ox+462.5]:
 for yy,dy in [(oy,1),(oy+458,-1)]:
  rect(xx-4.1,yy if dy==1 else yy-16.1,8.2,16.1,'#b91d27')
  for d in [4,12]:circle(xx,yy+dy*d,2.4,dark,'white')
# Exposed accessory studs, frame-local y points upward.
for r in range(3):
 for c in range(2):
  for xx,yy in LAYOUT['unit_stud_centers'][str(c)]:circle(ox+c*235+xx,oy+(r+1)*H-yy,2.4,red,dark)
for item in LAYOUT['items']:
 xx=ox+item['x'];yy=oy+458-item['y']-7.8
 rect(xx,yy,15.8,7.8,light,dark)
 lettering('price_'+{'yen':'yen','5':'five','0':'zero'}[item['char']],xx,yy,7.8)
for item in BARS['items']:
 xx,yy,zz=item['position']
 rect(ox+xx,oy+458-yy-7.8,95.8,7.8,red,dark)
for yy in [oy+H,oy+2*H]:line(ox,yy,ox+470,yy,red,True)
line(ox+235,oy,ox+235,oy+458,red,True)
anchors=[]
for r in range(2):
 for c,x in enumerate([7.5,462.5]):anchors.append((f'V{r*2+c+1}',ox+x,oy+(r+1)*H,True))
for r,y in enumerate([H-15,2*H-15,458-15]):anchors.append((f'H{r+1}',ox+235,oy+y,False))
for name,x,y,v in anchors:
 w,h=(7.8,31.8) if v else (31.8,7.8)
 rect(x-w/2,y-h/2,w,h,red)
 for d in [-12,-4,4,12]:circle(x+(0 if v else d),y+(d if v else 0),2.4,'none','white')
 text(name,x+(10 if x<ox+235 else -10) if v else x,y-4 if v else y-7,4,red,('start' if x<ox+235 else 'end') if v else 'middle')
hd(ox,ox+470,55,oy,'470');hd(ox,ox+235,73,oy,'235');hd(ox+235,ox+470,73,oy,'235');vd(oy,oy+458,28,ox,'458')
for r in range(3):vd(oy+r*H,oy+(r+1)*H,548,ox+470,'152.667')
text('取り付け方式',585,96,8)
notes(['札：正面の凹みへ押し込む','取り外し：正面へ引き抜く','大札は上端の長い赤バーで押さえる','1列12突起にはめる共通バー ×6','札の表面と枠の正面が面一'],585,114)
line(585,170,760,170)
text('つなぎパーツ',585,190,8)
notes(['正面から 1×4 パーツで橋渡し','V1〜V4：上下を接続','H1〜H3：左右を接続','各ユニット側に2個ずつの突起','部品本体：31.8 × 7.8 × 2.0','突起込み厚み：3.0','正面の凹み：深さ2.0','枠本体の厚み：6.0'],585,208)
line(585,302,760,302)
text('札と枠の寸法',585,323,8)
notes(['カテゴリー：100 × 28（各文字2枚）','商品名：8種類各1枚＋無地4枚','英日2段／文字は0.3mm彫込み','ベース赤／全札白／文字黒','外枠15 ／ 中央7.5＋7.5','上枠15 ／ 商品名の横枠30','段の境目は30＋15＝45'],585,341)
line(585,423,760,423)
text('試作条件',585,445,8)
notes(['枠は左右2種類 × 各3個／全部品PLA','価格：1文字ずつ独立／¥500⇄¥600','赤：正面にはめる接続パーツ','薄型専用キー／実物保持力は未確認','価格台座15.8×7.8×3.2／2穴'],585,464,size=4.8)
text('水色：全札の裏穴（点線・正面には見えない）　　赤：ユニットの接続部　　ベース470 × 458／バー付き470 × 459.4',55,577,6)
notes(['全札：裏側止まり穴Ø5.0・深さ2.2／ピンØ4.8・高さ2.0。彫込文字部でも表皮0.5mm以上で穴は見えません。','つなぎパーツは正面に装着。凹み底は裏面から4.0mm。左右2種類を同じ向きで各3個使用。上下端の未使用の半受けは残ります。','突起径4.8は設計基準値。純正金型と完全同一の形状・公差を保証するデータではありません。'],55,595,11,5)
save('01_front_dimensions.svg',790,640)
s.clear()
text('KURICH｜札・つなぎパーツのはめ込み構造',35,27,10)
text('V32  /  詳細模式図・寸法値は実寸mm  /  全札に裏側止まり穴2個＋対応ピン',35,42,5,muted)
text('01　札の裏穴2個を受けの2突起に合わせる',35,67,8)
# Side section through recessed socket, scale 8:1. Glass rear z=0; face z=5.
rect(40,96,4,88,'#bddcea');text('ガラス',42,201,5,muted,'middle')
rect(52,96,48,88,red)
rect(76,96,24,76,light,blue)
line(100,88,100,188,red,True)
text('面一 z=6',100,84,5,red,'middle')
hd(52,100,215,184,'全厚 6.0')
notes(['装着状態の側面断面（穴を避けた位置）','裏面 z=0 ／ 枠・札の表面 z=6','札の裏面 z=3 ／ 表面 z=6','受け深さ3mm／突起高さ2.0','厚み3mm／穴深さ2.2・表皮0.8','商品札は上辺を横枠上端に揃える'],180,101,16,5.5)
text('商品札の裏面：止まり穴を左右2か所',370,83,6)
rect(380,105,225,69,light,blue)
for dx in [8,67]:circle(380+dx*3,139.5,7.5,'white',blue)
text('商品札 75 × 23 × 3',505,148,7,blue,'middle')
notes(['穴中心：左から8・67／下から11.5','穴Ø5.0深さ2.2／ピンØ4.8高さ2.0','カテゴリ穴中心：(8,24)・(92,24)'],380,194,13,5.5)
line(35,240,735,240)
text('02　つなぎパーツは 1×4 サイズ',35,264,8)
text('表側：丸突起4個',50,288,6)
bx,by,k=60,313,5
rect(bx,by,31.8*k,7.8*k,red,dark)
for x in [3.9,11.9,19.9,27.9]:circle(bx+x*k,by+3.9*k,2.4*k,red,'white')
hd(bx,bx+159,301,by,'31.8');vd(by,by+39,42,bx,'7.8')
hd(bx+19.5,bx+59.5,374,by+39,'8.0')
text('突起径 Ø4.8 ／ 高さ1.0',60,391,6)
text('裏側：空洞＋中間柱3個',285,288,6)
rect(290,313,159,39,red,dark);rect(297.5,320.5,144,24,'white',dark)
for x in [7.9,15.9,23.9]:circle(290+x*5,332.5,8,red,dark)
notes(['壁厚1.5 ／ 内幅4.8','中間柱 Ø3.2 ／ 空洞深さ1.2','表面の丸突起をこの空洞で保持'],285,374,12,5.5)
text('側面',510,288,6)
rect(515,326,159,10,red,dark)
for x in [3.9,11.9,19.9,27.9]:rect(515+(x-2.4)*5,321,24,5,red,dark)
vd(326,336,695,674,'2.0');vd(321,336,720,674,'3.0')
notes(['基準：8mm間隔の1×4プレート','裏側の壁・柱は試作用の簡略形状','薄型専用設計：純正LEGOと高さ非互換'],510,374,12,5)
line(35,424,735,424)
text('03　継ぎ目を正面から橋渡しする',35,449,8)
rect(65,479,72,120,red);rect(137.5,479,72,120,red)
rect(89.5,519.5,96,39,red,dark)
for dx in [-12,-4,4,12]:circle(137.5+dx*3,539,7.2,'none','white')
line(137.5,470,137.5,607,red,True)
text('ユニットA',100,493,5,'white','middle');text('ユニットB',175,493,5,'white','middle')
text('2突起ずつを1枚でつなぐ',137.5,621,6,red,'middle')
notes(['正面から見た図（左右接続の例）','部品の中心を継ぎ目に合わせる','突起位置：継ぎ目から±4、±12','上下接続は同じ部品を90°回転','枠本体は突き合わせ、重なりなし'],255,485,15,6)
notes(['枠の正面に深さ2.0の凹みを設ける','凹み底の前向き突起1.0に押し込む','本体面は枠と面一・突起だけ1mm前へ','7個とも正面から装着・取り外し','保持力は試験パーツで確認'],500,485,15,5.5)
text('公称寸法を使った互換試作です。PLA出力品と純正品の完全互換・同じクリック感は、まだ確認していません。',35,653,5,red)
save('02_fitting_details.svg',770,675)
print('Created two editable dimensioned SVG drawings')

s.clear()
text('KURICH｜札の埋込断面：価格部は別途突出',30,25,9)
text('V32 / 断面模式図 / 数値は実寸mm / 描画倍率15:1',30,40,5,muted)
# Diagram horizontal axis is actual z depth. Plate occupies z=5..8.
X,Y,K=75,75,15
rect(X-12,Y,5,150,'#bddcea')
rect(X,Y,6*K,150,red)
# 3 mm plate in a 3 mm recess; section avoids the blind pockets.
rect(X+3*K,Y,3*K,125,light,blue)
line(X+6*K,Y-10,X+6*K,Y+160,red,True)
hd(X,X+6*K,Y+180,Y+150,'全体の厚み 6.0')
hd(X+3*K,X+6*K,Y-12,Y+25,'札 3.0')
text('ガラス側',X-10,Y+165,5,muted,'middle')
text('正面：枠と札が同じ位置',X+6*K,Y+165,5,red,'middle')
notes(['枠の裏面：z = 0','凹み底／札の裏面：z = 3.0','全札：厚み3／裏穴Ø5.0深さ2.2','全札の表皮0.8／ピンØ4.8','枠と札の表面：z = 6.0','つなぎパーツ先端：z = 7.0'],265,90,19,6)
notes(['水色：厚み3mmの商品札（穴を避けた断面）','ピン先端z=5.0。穴天井z=5.2との隙間0.2mm。','札の外周には片側0.2mmの隙間。商品札上辺は横枠上端と一致。','カテゴリー札は下端を持って取り外せます。','商品札の受けは上辺が開放。上の細い横棒はありません。','価格前面z9.2／押さえバー前面z9.5（全厚）。保持力未確認。'],30,285,15,5.5)
save('03_side_flush.svg',540,385)

s.clear()
text('KURICH｜外付け価格・独立文字タイル',25,25,9)
text('V32／単位mm／1文字を2つの突起で位置決め',25,40,5)
for i,t in enumerate(['¥','5','0','0']):
 rect(30+i*80,65,63.2,31.2,light,dark)
 lettering('price_'+['yen','five','zero','zero'][i],30+i*80,65,7.8,4)
 for dx in [3.9,11.9]:circle(30+i*80+dx*4,80.6,10,'none',blue,True)
text('分解表示：¥／5／0／0 の4枚。装着時の全幅63.8mm。',30,118,5)
notes(['各台座15.8×7.8×3.2／裏側止まり穴Ø5.0×深さ1.8を2個','穴中心間8mm／追加突起Ø4.8×高さ1.6／文字彫込み0.3','¥・5・0・0を全カテゴリー文字の下に装着。5を6に替えて¥600。','全カテゴリー価格は札前面の突起8個へ装着。文字位置は維持。','価格台座は枠外へ突出なし／上端バー込み470×459.4。','厚み：ベース6／追加突起先端7.6／価格タイル前面9.2。','公開基準LDraw寸法を参考。純正同一形状・保持力は未検証。'],25,145,15,5)
save('04_price_tiles.svg',430,265)

s.clear()
text('KURICH｜カテゴリー札の1列押さえバー',25,25,9)
text('V32／赤い1本部品×6／寸法mm／小クリップ・専用スライド溝は廃止',25,40,5)
rect(35,65,300,15,red,dark)
rect(35,80,300,80,light,dark)
rect(41.3,60.8,287.4,23.4,red,dark)
for i in range(12):circle(41.3+(3.9+i*8)*3,72.5,7.5,'none','white',True)
text('カテゴリー札',185,141,9,dark,'middle')
hd(41.3,328.7,181,84.2,'バー長さ95.8')
notes(['本体95.8×7.8×3.2／裏側の丸い止まり穴12個','穴径5.0・深さ1.6／8mm間隔の既存突起にはめ込む','バーの下端が札の上端を1.4mm覆い、正面への抜けを押さえる','札との前後隙間0.3／バー裏z6.3・前面z9.5','外す順：長いバーを手前へ外す → カテゴリー札を外す','ベース外寸470×458／バー込み470×459.4×9.5','バー自身の保持は突起とのはめ合い。実物保持力・PLA強度は未検証'],25,215,15,5)
save('05_category_retainer.svg',470,335)
