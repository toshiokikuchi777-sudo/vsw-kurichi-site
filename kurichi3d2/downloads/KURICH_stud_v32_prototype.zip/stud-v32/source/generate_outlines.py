from pathlib import Path
import json,math,tempfile
from fontTools.ttLib import TTCollection
from matplotlib.textpath import TextPath
from matplotlib.font_manager import FontProperties
from matplotlib.ft2font import FT2Font
ROOT=Path(__file__).resolve().parent
font='/System/Library/Fonts/Supplemental/Futura.ttc';jp='/Users/kikuchitoshio/Library/Fonts/NotoSansJP-Black.otf'
# Extract face2 only to an ephemeral file; no font is distributed.
with tempfile.TemporaryDirectory() as tmp:
 face=Path(tmp)/'FuturaBold.ttf';TTCollection(font).fonts[2].save(face)
 def outlines(word,path,w,h,cx,cy,italic=False):
  f=FT2Font(str(path));assert all(f.get_char_index(ord(c))>0 for c in word if not c.isspace()),word
  p=TextPath((0,0),word,size=12,prop=FontProperties(fname=str(path)))
  polys=p.to_polygons()
  if italic:
   for q in polys:q[:,0]+=math.tan(math.radians(12))*q[:,1]
  import numpy as np
  allp=np.vstack(polys);lo=allp.min(axis=0);hi=allp.max(axis=0);size=hi-lo;sc=min(w/size[0],h/size[1])
  return [((q-lo)*sc+[cx-size[0]*sc/2,cy-size[1]*sc/2]).tolist() for q in polys]
 out={}
 for word in ['CLASIC','FUWA_MOCHI','WOOPEE']:out[word]=outlines(word,face,84,10,50,14,True)
 for slug,en,ja in json.loads((ROOT/'product_names.json').read_text()):
  out[slug]=outlines(en,face,65,5,37.5,16.5,True)+outlines(ja,jp,65,5.8,37.5,6.7)
 for slug,char in [('yen','¥'),('five','5'),('six','6'),('zero','0')]:out['price_'+slug]=outlines(char,face,10,5.5,7.9,3.9,True)
 (ROOT/'text_outlines.json').write_text(json.dumps(out))
 print('Generated all glyph outlines; missing-glyph check passed')
