from pathlib import Path
import zipfile,xml.etree.ElementTree as ET,json
import trimesh,numpy as np
root=Path(__file__).resolve().parent.parent
rows=[]
for p in sorted(root.rglob('*.3mf')):
 with zipfile.ZipFile(p) as z:e=ET.fromstring(z.read('3D/3dmodel.model'))
 ns={'m':'http://schemas.microsoft.com/3dmanufacturing/core/2015/02'}
 assert e.attrib['unit']=='millimeter'
 v=[[float(n.attrib[k]) for k in ['x','y','z']] for n in e.findall('.//m:vertex',ns)]
 f=[[int(n.attrib[k]) for k in ['v1','v2','v3']] for n in e.findall('.//m:triangle',ns)]
 m=trimesh.Trimesh(v,f,process=True);s=trimesh.load(p.with_suffix('.stl'))
 assert m.is_watertight and len(m.split())==1
 assert np.allclose(m.bounds,s.bounds,atol=1e-5)
 assert np.isclose(m.volume,s.volume,rtol=1e-6)
 rows.append({'file':str(p.relative_to(root)),'unit':'millimeter','watertight':True,'components':1,'matches_stl_bounds_and_volume':True})
(root/'3mf_validation.json').write_text(json.dumps(rows,indent=2))
print('Validated',len(rows),'3MF files')
